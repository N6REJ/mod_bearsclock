BearsClock
![GitHub release (latest by date)](https://img.shields.io/github/v/release/N6REJ/mod_bearsclock)
![GitHub top language](https://img.shields.io/github/languages/top/N6REJ/mod_bearsclock)
![GitHub All Releases](https://img.shields.io/github/downloads/N6REJ/mod_bearsclock/total)
![License: GPL v3](https://img.shields.io/badge/License-GPLv3-blue.svg)
========
A live-clock based on Javascript and PHP. By using PHP together with Javascript this clock can get the time for a specified timezone trough PHPs much more advanced date() function and then keep the clock going with javascript. Supported timezones can be found at www.php.net/manual/en/timezones.php.

![image](https://github.com/user-attachments/assets/5f86fbb1-7e3f-4894-a8f7-b4d8f0188703)

